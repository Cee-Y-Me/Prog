﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Part3
{
    public class Recipe
    {
        public string Rname { get; set; }

        public string Iname { get; set; }

        public double Quantity { get; set; }

        public string Unit { get; set; }

        public double Calories { get; set; }

        public string Food { get; set; }

        public string Step { get; set; }
    }
}
