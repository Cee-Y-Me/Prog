﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Part3
{
    /// <summary>
    /// Interaction logic for ScaleWindow.xaml
    /// </summary>
    public partial class ScaleWindow : Window
    {
        public List<Recipe> RecipesCopy = new List<Recipe>();
        public ScaleWindow()
        {
            InitializeComponent();
        }
        private void btnScale_Click(object sender, RoutedEventArgs e)
        {
            foreach (var recipe in RecipesCopy)
            {
                if (recipe.Iname.Equals(txtSearch.Text))
                {
                    if (radAdjust2.IsChecked == true)
                    {
                        recipe.Quantity *= 0.5;
                    }
                    else if (radAdjust5.IsChecked == true)
                    {
                        recipe.Quantity *= 2;
                    }
                    else
                    {
                        recipe.Quantity *= 3;
                    }
                }


            }

        }

        private void btnShow_Click(object sender, RoutedEventArgs e)
        {
            var theRecipe = from recipe in RecipesCopy select recipe;

            foreach (var recipe in theRecipe)
            {
                lstShow.Items.Add(recipe.Iname + " - " + recipe.Quantity);
            }
        }

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {

            MainWindow main = new MainWindow();
            main.recipes.AddRange(RecipesCopy);
            this.Close();
        }
    }
}
