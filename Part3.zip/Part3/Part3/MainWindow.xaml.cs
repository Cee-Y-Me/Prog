﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Part3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public List<Recipe> recipes = new List<Recipe>();
        public MainWindow()
        {
            InitializeComponent();
        }
        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            recipes.Add(new Recipe()
            {
                Rname = txtRname.Text,
                Iname = txtIname.Text,
                Quantity = double.Parse(txtQuantity.Text),
                Unit = txtUnit.Text,
                Calories = double.Parse(txtCalories.Text),
                Food = txtFood.Text,
                Step = txtStep.Text,
            });
            txtRname.Text = "";
            txtIname.Text = "";
            txtQuantity.Text = "";
            txtUnit.Text = "";
            txtCalories.Text = "";
            txtFood.Text = "";
            txtStep.Text = "";
            txtIname.Focus();
        }

        private void btnDisplay_Click(object sender, RoutedEventArgs e)
        {
            lstDisplay.Items.Clear();
            foreach (Recipe recipe in recipes)
            {
                lstDisplay.Items.Add(recipe.Iname);
            }
        }

        private void lstDisplay_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            foreach (var recipe in recipes)
            {
                if (lstDisplay.SelectedItem.ToString().Equals(recipe.Iname))
                {
                    lstDisplayAll.Items.Add(recipe.Rname + " - " + recipe.Iname + " - " + recipe.Quantity + recipe.Unit + " - " + recipe.Calories + " - " + recipe.Food + " - " + recipe.Step);
                    MessageBox.Show(recipe.Rname + " - " + recipe.Iname + " - " + recipe.Quantity + recipe.Unit + " - " + recipe.Calories + " - " + recipe.Food + " - " + recipe.Step);
                }

            }
        }

        private void btnScale_Click(object sender, RoutedEventArgs e)
        {
            ScaleWindow scaleWindow = new ScaleWindow();
            scaleWindow.RecipesCopy.AddRange(recipes);
            scaleWindow.Show();
        }

        private void lstDisplayAll_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            foreach (var recipe in recipes)
            {
                if (lstDisplay.SelectedItem.ToString().Equals(recipe.Iname))
                {
                    lstDisplayAll.Items.Add(recipe.Rname + " - " + recipe.Iname + " - " + recipe.Quantity + recipe.Unit + " - " + recipe.Calories + " - " + recipe.Food + " - " + recipe.Step);
                    MessageBox.Show(recipe.Rname + " - " + recipe.Iname + " - " + recipe.Quantity + recipe.Unit + " - " + recipe.Calories + " - " + recipe.Food + " - " + recipe.Step);
                }

            }
        }

        private void btnCalories_Click(object sender, RoutedEventArgs e)
        {
            CaloriesWindow caloriesWindow = new CaloriesWindow();
            caloriesWindow.RecipesDentical.AddRange(recipes);
            caloriesWindow.Show();
        }

        private void txtCalories_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
